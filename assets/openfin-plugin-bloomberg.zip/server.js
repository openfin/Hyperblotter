'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

require('source-map-support/register');

var getenv = require('getenv'); // helps to get and typecast environment variables

// Check environment variables
var SOCKET_IO_PORT = getenv.int('SOCKET_IO_PORT', 8198);
var BLOOMBERG_PORT = getenv.int('BLOOMBERG_PORT', 8194);
var BLOOMBERG_HOST = getenv.string('BLOOMBERG_HOST', 'localhost');

// Setup communication with a client
var server = require('http').Server();
var io = require('socket.io')(server);
server.listen(SOCKET_IO_PORT);

var blpapi = require('blpapi');
// var blpapi = require('./emulator.js');
var errorTopic = 'plugin-error';
var requestTopic = 'plugin-request';
var sessionArgs = { serverHost: BLOOMBERG_HOST, serverPort: BLOOMBERG_PORT };

io.on('connection', function (socket) {
    // Each opened socket is a new blpapi session
    var session = new blpapi.Session(sessionArgs);

    socket.on(requestTopic, function (m) {
        if (m.functionName === 'on') {
            // Add an event listener
            session.on(m.event, function (d) {
                return socket.emit(m.event, _extends(m, { payload: d }));
            });
        } else {
            // Try to execute a function from blpapi session
            try {
                session[m.functionName].apply(session, m.args);
            } catch (err) {
                // Send error message to client for all exceptions
                socket.emit(errorTopic, _extends(m, { message: err.message, stack: err.stack.replace(/↵/g, "\n") }));
            }
        }
    });
});
//# sourceMappingURL=server.js.map
